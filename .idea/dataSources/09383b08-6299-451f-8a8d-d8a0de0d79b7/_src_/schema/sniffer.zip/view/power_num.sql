CREATE VIEW power_num AS
  SELECT
    `a`.`client` AS `client`,
    `a`.`time`   AS `time`,
    count(0)     AS `row_num`
  FROM (`sniffer`.`power` `a`
    JOIN `sniffer`.`power` `b` ON (((`a`.`client` = `b`.`client`) AND (`a`.`time` >= `b`.`time`))))
  GROUP BY `a`.`client`, `a`.`time`;
